/*********************************************************************************
* WEB322 – Assignment 02
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part
* of this assignment has been copied manually or electronically from any other source
* (including 3rd party web sites) or distributed to other students.
*
* Name: Shweyin Than  Student ID: 115675175 Date: 7/12/2018
*
* Online (Heroku) Link: https://secure-citadel-38924.herokuapp.com/
*
********************************************************************************/ 
var express = require('express');
var dataService = require(__dirname + '/data-service.js');
var app = express();
var multer = require('multer');
var fs = require('fs');
var path = require('path');
var bodyParser = require('body-parser');
var exphbs = require('express-handlebars');

var HTTP_PORT = process.env.PORT || 8080;
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static('public'));
app.use(function(req,res,next){
    let route = req.baseUrl + req.path;
    app.locals.activeRoute = (route == "/") ? "/" : route.replace(/\/$/, "");
    next();
});

app.engine('.hbs', exphbs({ 
    extname: '.hbs', 
    defaultLayout: 'main',
    helpers: {
        navLink: function(url, options){
            return '<li' +
            ((url == app.locals.activeRoute) ? ' class="active" ' : '') + 
            '><a href="' + url + '">' + options.fn(this) + '</a></li>';
        },
        equal: function (lvalue, rvalue, options) {
            if (arguments.length < 3)
            throw new Error("Handlebars Helper equal needs 2 parameters");
            if (lvalue != rvalue) {
            return options.inverse(this);
            } else {
            return options.fn(this);
            }
        }   
    }
}));
app.set('view engine', '.hbs');

const storage = multer.diskStorage({
    destination: "./public/images/uploaded",
    filename: function (req, file, cb) {
      cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({storage: storage});

app.post('/images/add', upload.single("imageFile"), function(req, res){
    res.redirect("/images");
});
app.post("/employees/add", (req, res) =>{
    dataService.addEmployee(req.body)
    .then((data)=>{
        res.redirect("/employees");
    }).catch((err)=>{
        console.log(err);
    });
});
app.post("/employee/update", (req, res) => {
    console.log(req.body);
    dataService.updateEmployee(req.body)
    .then((data)=>{
        res.redirect("/employees");
    }).catch((err)=>{
        console.log(req.body);
        console.log(err);
    });
});
   



app.get('/', function(req, res){
    res.render(__dirname + '/views/home.hbs');
});
app.get('/employees/add', function(req, res){
    res.render(__dirname + '/views/addEmployee.hbs');
});
app.get('/images/add', function(req, res){
    res.render(__dirname + '/views/addImage.hbs')
});
app.get('/about', function(req, res)
{
    res.render(__dirname + '/views/about.hbs');
});
app.get('/images', function (req, res){
    fs.readdir(__dirname + "/public/images/uploaded", function(err, items) {
        res.render('images', {data: items});
        //res.json(items);
    });
});
app.get('/employees', function(req, res)
{
    if(req.query.status)
    {
        dataService.getEmployeesByStatus(req.query.status)
        .then(function(result)
        {
            //res.json(result);
            res.render('employees', {data: result});
        })
        .catch(function(err){
            console.log(err);
        });
    }
    else if(req.query.department)
    {
        dataService.getEmployeesByDepartment(req.query.department)
        .then(function(result)
        {
            //res.json(result);
            res.render('employees', {data: result});
        })
        .catch(function(err){
            console.log(err);
        });
    }
    else if(req.query.manager)
    {
        dataService.getEmployeesByManager(req.query.manager)
        .then(function(result)
        {
            //res.json(result);
            res.render('employees', {data: result});
        })
        .catch(function(err){
            console.log(err);
        });
    }
    else
    {
        dataService.getAllEmployees()
        .then(function(result)
        {
            //res.json(result);
            res.render('employees', {data: result});
        })
        .catch(function(err){
            console.log(err);
        });
    }
});

app.get('/employee/:value', function(req, res){
    dataService.getEmployeeByNum(req.params.value)
        .then(function(result)
        {
            //res.json(result);
            //console.log(result);
            res.render("employee", {data: result});
        })
        .catch(function(err){
            console.log(err);
            //res.render("employee",{message:"no results"});
        });
});

app.get('/managers', function(req, res)
{
    dataService.getManagers()
    .then(function(result)
    {
        res.json(result);
    })
    .catch(function(err){
        console.log(err);
    });
});
app.get('/departments', function(req, res)
{
    dataService.getDepartments()
    .then(function(result)
    {
        //res.json(result);
        res.render('departments', {data: result});
    })
    .catch(function(err){
        console.log(err);
    });
});

dataService.initialize()
.then(function()
{
    app.listen(HTTP_PORT, onhttpstart())
})
.catch(function(err){
    console.log(err);
});

app.get('*', function(req, res)
{
    res.status(404).send('Error 404: Sorry, this page does not exist :(');
});
function onhttpstart(){
    console.log('server listening on port: ' + HTTP_PORT);
};