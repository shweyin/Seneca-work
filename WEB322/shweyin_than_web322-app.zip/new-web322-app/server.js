/*********************************************************************************
* WEB322 – Assignment 02
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part
* of this assignment has been copied manually or electronically from any other source
* (including 3rd party web sites) or distributed to other students.
*
* Name: Shweyin Than  Student ID: 115675175 Date: 6/3/2018
*
* Online (Heroku) Link: https://secure-citadel-38924.herokuapp.com/
*
********************************************************************************/ 
var express = require('express');
var dataService = require(__dirname + '/data-service.js');
var app = express();
var multer = require('multer');
var fs = require('fs');
var path = require('path');
var bodyParser = require('body-parser');

var HTTP_PORT = process.env.PORT || 8080;
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static('public'));

const storage = multer.diskStorage({
    destination: "./public/images/uploaded",
    filename: function (req, file, cb) {
      cb(null, Date.now() + path.extname(file.originalname));
    }
  });

const upload = multer({storage: storage});

app.get('/images', function (req, res){
    fs.readdir(__dirname + "/public/images/uploaded", function(err, items) {
        res.json(items);
    });
});

app.post('/images/add', upload.single("imageFile"), function(req, res){
    res.redirect("/images");
});


app.get("/employees/add", function(req,res){
    res.sendFile(__dirname + "/views/addEmployee.html");
});
 
app.post("/employees/add", (req, res) =>{
    dataService.addEmployee(req.body)
    .then((data)=>{
        res.redirect("/employees");
    }).catch((err)=>{
        console.log(err);
    })
});


app.get('/', function(req, res){
    res.sendFile(__dirname + '/views/home.html');
});
app.get('/home', function(req, res){
    res.sendFile(__dirname + '/views/home.html');
});
app.get('/employees/add', function(req, res){
    res.sendFile(__dirname + '/views/addEmployee.html')
});
app.get('/images/add', function(req, res){
    res.sendFile(__dirname + '/views/addImage.html')
});
app.get('/about', function(req, res)
{
    res.sendFile(__dirname + '/views/about.html');
});
app.get('/employees', function(req, res)
{
    if(req.query.status)
    {
        dataService.getEmployeesByStatus(req.query.status)
        .then(function(result)
        {
            res.json(result);
        })
        .catch(function(err){
            console.log(err);
        });
    }
    else if(req.query.department)
    {
        dataService.getEmployeesByDepartment(req.query.department)
        .then(function(result)
        {
            res.json(result);
        })
        .catch(function(err){
            console.log(err);
        });
    }
    else if(req.query.manager)
    {
        dataService.getEmployeesByManager(req.query.manager)
        .then(function(result)
        {
            res.json(result);
        })
        .catch(function(err){
            console.log(err);
        });
    }
    else
    {
        dataService.getAllEmployees()
        .then(function(result)
        {
            res.json(result);
        })
        .catch(function(err){
            console.log(err);
        });
    }
});

app.get('/employees/:value', function(req, res){
    dataService.getEmployeeByNum(req.params.value)
        .then(function(result)
        {
            res.json(result);
        })
        .catch(function(err){
            console.log(err);
        });
});

app.get('/managers', function(req, res)
{
    dataService.getManagers()
    .then(function(result)
    {
        res.json(result);
    })
    .catch(function(err){
        console.log(err);
    });
});
app.get('/departments', function(req, res)
{
    dataService.getDepartments()
    .then(function(result)
    {
        res.json(result);
    })
    .catch(function(err){
        console.log(err);
    });
});

dataService.initialize()
.then(function()
{
    app.listen(HTTP_PORT, onhttpstart())
})
.catch(function(err){
    console.log(err);
});

app.get('*', function(req, res)
{
    //Deprecated: res.send('Error 404: Sorry, this page does not exist(It would be awesome if it did though)', 404);
    res.status(404).send('Error 404: Sorry, this page does not exist :(');
});
function onhttpstart(){
    console.log('server listening on port: ' + HTTP_PORT);
};