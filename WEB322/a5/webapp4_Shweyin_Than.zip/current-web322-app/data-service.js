var Sequelize = require('sequelize');
var sequelize = new Sequelize('ds49q63qn4vo3', 'fbqgpzoqfvdgmv', 'a44982a7e8971eddca85210bcce17ad4d525e9758452acaa15ed4f0b2580b392', {
    host: 'ec2-107-21-236-219.compute-1.amazonaws.com',
    dialect: 'postgres',
    port: 5432,
    dialectOptions: {
    ssl: true
    }
   });

var Employee = sequelize.define('Employee', {
    employeeNum: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    firstName: Sequelize.STRING,
    lastName: Sequelize.STRING,
    email: Sequelize.STRING,
    SSN: Sequelize.STRING,
    addressStreet: Sequelize.STRING,
    addressCity: Sequelize.STRING,
    addressState: Sequelize.STRING,
    addressPostal: Sequelize.STRING,
    maritalStatus: Sequelize.STRING,
    isManager: Sequelize.BOOLEAN,
    employeeManagerNum: Sequelize.INTEGER,
    status: Sequelize.STRING,
    department: Sequelize.INTEGER,
    hireDate: Sequelize.STRING
});

var Department = sequelize.define('Department', {
    departmentId: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    departmentName: Sequelize.STRING
});

module.exports.initialize = function()
{
    return new Promise(function (resolve, reject) {
        sequelize.sync().then(function () {
            resolve('Sync Success!');
        }).catch(function () {
            reject('Unable to Sync Database');
        });
    });       
};

module.exports.getAllEmployees = function()
{
    return new Promise(function (resolve, reject) {
        Employee.findAll().then(function (data) {
            resolve(data);
        }).catch(function (){
            reject('Unable to findAll() employees');
        });
    });  
};

module.exports.getManagers =function ()
{
    return new Promise(function (resolve, reject) {
        reject();
       });  
}

module.exports.getDepartments = function()
{
    return new Promise(function (resolve, reject) {
        Department.findAll().then(function(data){
            resolve(data);
        }).catch(function(){
            reject('Unable to findAll() departments');
        });
    });  
};

module.exports.addEmployee = function(employeeData)
{
    return new Promise(function (resolve, reject) {
        employeeData.isManager = (employeeData.isManager) ? true : false;
        console.log(employeeData);
        for (var empOBJ in employeeData) {
            if (employeeData[empOBJ] == "") {
                employeeData[empOBJ] = null;
                console.log('if');
            }
            console.log("for");
        }
        Employee.create({
            employeeNum: employeeData.employeeNum,
            firstName: employeeData.firstName,
            lastName: employeeData.lastName,
            email: employeeData.email,
            SSN: employeeData.SSN,
            addressStreet: employeeData.addressStreet,
            addressCity: employeeData.addressCity,
            addressState: employeeData.addressState,
            addressPostal: employeeData.addressPostal,
            //maritalStatus: employeeData.maritalStatus,
            isManager: employeeData.isManager,
            employeeManagerNum: employeeData.employeeManagerNum,
            status: employeeData.status,
            department: employeeData.department,
            hireDate: employeeData.hireDate
        }).then(function () {
            resolve();
        }).catch(function() {
            reject('Unable To add employee');
    });  
})};

module.exports.getEmployeesByStatus = function(qstatus)
{
    return new Promise(function (resolve, reject) {
        Employee.findAll({
            where: {
                status: qstatus
            }
        }).then(function (data) {
            resolve(data);
        }).catch(function (){
            reject('Unable to findAll() employees by status');
        });
    });  
};

module.exports.getEmployeesByDepartment = function(qdepartment)
{
    return new Promise(function (resolve, reject) {
        Employee.findAll({
            where: {
                department: qdepartment
            }
        }).then(function(data){
            resolve(data);
        }).catch(function(){
            reject('Unable to findAll() employees by department');
        });
    });  
};

module.exports.getEmployeesByManager = function(qmanager)
{
    return new Promise(function (resolve, reject) {
        Employee.findAll({
            where: {
                employeeManagerNum: qmanager
            }
        }).then(function(data){
            resolve(data);
        }).catch(function(){
            reject('Unable to findAll() employees by manager num');
        });
    });  
};

module.exports.getEmployeeByNum = function(num)
{
    return new Promise(function (resolve, reject) {
        Employee.findAll({
            where: {
                employeeNum: num
            }
        }).then(function(data){
            resolve(data);
        }).catch(function(){
            reject('Unable to findAll() employees by employeeNum');
        });
    });  
};

module.exports.updateEmployee = function(employeeData)
{
    return new Promise(function (resolve, reject) {
        employeeData.isManager = (employeeData.isManager) ? true : false;
        for (var empOBJ in employeeData) {
            if (employeeData[empOBJ] == "") {
                employeeData[empOBJ] = null;
            }
        }
        Employee.update({
            employeeNum: employeeData.employeeNum,
            firstName: employeeData.firstName,
            lastName: employeeData.lastName,
            email: employeeData.email,
            SSN: employeeData.SSN,
            addressStreet: employeeData.addressStreet,
            addressCity: employeeData.addressCity,
            addressState: employeeData.addressState,
            addressPostal: employeeData.addressPostal,
            //maritalStatus: employeeData.maritalStatus,
            isManager: employeeData.isManager,
            employeeManagerNum: employeeData.employeeManagerNum,
            status: employeeData.status,
            department: employeeData.department,
            hireDate: employeeData.hireDate
        },
        {
            where: {employeeNum: employeeData.employeeNum}
        }).then(function () {
            resolve();
        }).catch(function() {
            reject('Unable to update employee');
        });
    });  
};

module.exports.addDepartment = function(departmentData)
{
    return new Promise(function (resolve, reject) {
        for (var DepOBJ in departmentData) {
            if (departmentData[DepOBJ] == "") {
                departmentData[DepOBJ] = null;
            }
        }
        Department.create({
            departmentId: departmentData.departmentId,
            departmentName: departmentData.departmentName
        }).then(function(){
            resolve();
        }).catch(function(){
            reject('Unable to add department');
        });
    });  
};

module.exports.updateDepartment = function(departmentData)
{
    return new Promise(function (resolve, reject) {
        for (var DepOBJ in departmentData) {
            if (departmentData[DepOBJ] == "") {
                departmentData[DepOBJ] = null;
            }
        }
        Department.update({
            departmentId: departmentData.departmentId,
            departmentName: departmentData.departmentName
        },
        {
            where: {departmentId: departmentData.departmentId}
        }
        ).then(function(){
            resolve();
        }).catch(function(){
            reject('Unable to update department');
        });
    });  
};

module.exports.getDepartmentById = function(id)
{
    return new Promise(function (resolve, reject) {
        Department.findAll({
            where: {departmentId: id}
        }).then(function(data){
            resolve(data);
        }).catch(function(){
            reject('Unable to find department by id');
        });
    });  
};

module.exports.deleteEmployeeByNum = function(empNum)
{
    return new Promise(function (resolve, reject) {
        Employee.destroy({
            where: {employeeNum: empNum}
        }).then(function () {
            resolve();
        }).catch (function(){
            reject("unable to delete employee");
        });
    });
};