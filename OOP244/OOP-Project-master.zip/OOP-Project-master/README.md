# OOP-Project

**IMPORTANT DATES:**

| Milestone                  | Deadline             |
| -------------------------- |--------------------- |
| *The `Date` class*         | **Due: March 16th**  |
| *The `ErrorMessage` class* | **Due: March 23rd**  |
| *The `Product` class*      | **Due: April  9th**  |
| *The `iProduct` interface* | **Due: April 11th**  | 
| *The `Perishable` class*   | **Due: April 16th**  |

