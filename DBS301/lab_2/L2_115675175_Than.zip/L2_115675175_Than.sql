SELECT employee_id, last_name, salary
FROM