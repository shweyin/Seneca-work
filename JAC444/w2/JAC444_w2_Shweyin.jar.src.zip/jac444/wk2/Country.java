package jac444.wk2;

public class Country
{
  String name;
  double areaKm2;
}


/* Location:              C:\Users\Shweyin\Desktop\Github\Seneca-work\JAC444\JAC444_w2_Shweyin.jar!\jac444\wk2\Country.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */