/*    */ package jac444.wk2;
/*    */ 
/*    */ public class Point {
/*    */   private double x;
/*    */   private double y;
/*    */   
/*    */   public Point(double conX, double conY) {
/*  8 */     this.x = conX;
/*  9 */     this.y = conY;
/*    */   }
/*    */   
/*    */   public double getX() {
/* 13 */     return this.x;
/*    */   }
/*    */   
/*    */   public double getY() {
/* 17 */     return this.y;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 21 */     return toString();
/*    */   }
/*    */   
/*    */   public boolean equals(Point obj) {
/* 25 */     return equals(obj);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 29 */     return hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\Shweyin\Desktop\Github\Seneca-work\JAC444\JAC444_w2_Shweyin.jar!\jac444\wk2\Point.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */