/*    */ package jac444.wk2;
/*    */ 
/*    */ public abstract class Shape {
/*    */   Point point;
/*    */   
/*    */   public Shape() {
/*  7 */     this.point = new Point(0.0D, 0.0D);
/*    */   }
/*    */   
/*    */   public void moveBy(double movX, double movY) {
/* 11 */     double tempX = this.point.getX();
/* 12 */     double tempY = this.point.getY();
/* 13 */     this.point = new Point(tempX + movX, tempY + movY);
/*    */   }
/*    */   
/*    */   public abstract Point getCentre();
/*    */ }


/* Location:              C:\Users\Shweyin\Desktop\Github\Seneca-work\JAC444\JAC444_w2_Shweyin.jar!\jac444\wk2\Shape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */