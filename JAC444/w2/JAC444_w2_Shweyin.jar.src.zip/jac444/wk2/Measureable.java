package jac444.wk2;

public abstract interface Measureable
{
  public abstract String getArea();
}


/* Location:              C:\Users\Shweyin\Desktop\Github\Seneca-work\JAC444\JAC444_w2_Shweyin.jar!\jac444\wk2\Measureable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */