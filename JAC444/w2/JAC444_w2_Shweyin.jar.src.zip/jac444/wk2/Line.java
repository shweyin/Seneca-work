/*    */ package jac444.wk2;
/*    */ 
/*    */ public class Line extends Shape {
/*    */   Point p1;
/*    */   Point p2;
/*    */   
/*    */   public Line(Point from, Point to) {
/*  8 */     this.p1 = from;
/*  9 */     this.p2 = to;
/*    */   }
/*    */   
/*    */   public Point getCentre() {
/* 13 */     Point lineCenter = new Point((this.p1.getX() + this.p2.getX()) / 2.0D, (this.p1.getY() + this.p2.getY()) / 2.0D);
/* 14 */     return lineCenter;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shweyin\Desktop\Github\Seneca-work\JAC444\JAC444_w2_Shweyin.jar!\jac444\wk2\Line.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */