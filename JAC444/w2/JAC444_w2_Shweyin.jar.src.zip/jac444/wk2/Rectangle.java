/*    */ package jac444.wk2;
/*    */ 
/*    */ public class Rectangle extends Shape {
/*    */   Point topLeft;
/*    */   double width;
/*    */   double length;
/*    */   
/*    */   public Rectangle(Point conTopLeft, double conWidth, double conLength) {
/*  9 */     this.topLeft = conTopLeft;
/* 10 */     this.width = conWidth;
/* 11 */     this.length = conLength;
/*    */   }
/*    */   
/*    */   public Point getCentre()
/*    */   {
/* 16 */     Point recCenter = new Point(this.topLeft.getX() + this.length / 2.0D, this.topLeft.getY() + this.width / 2.0D);
/* 17 */     return recCenter;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shweyin\Desktop\Github\Seneca-work\JAC444\JAC444_w2_Shweyin.jar!\jac444\wk2\Rectangle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */