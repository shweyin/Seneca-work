/*    */ package jac444.wk2;
/*    */ 
/*    */ public class LabeledPoint extends Point {
/*    */   private String label;
/*    */   
/*  6 */   public LabeledPoint(String conLabel, double conX, double conY) { super(conX, conY);
/*  7 */     this.label = new String(conLabel);
/*    */   }
/*    */   
/*    */   public String getLabel() {
/* 11 */     return this.label;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shweyin\Desktop\Github\Seneca-work\JAC444\JAC444_w2_Shweyin.jar!\jac444\wk2\LabeledPoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */