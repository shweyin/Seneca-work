/*    */ package jac444.wk2;
/*    */ 
/*    */ public class Circle extends Shape {
/*    */   Point center;
/*    */   double radius;
/*    */   
/*    */   public Circle(Point conCentre, double conRadius) {
/*  8 */     this.center = conCentre;
/*  9 */     this.radius = conRadius;
/*    */   }
/*    */   
/*    */   public Point getCentre() {
/* 13 */     return this.center;
/*    */   }
/*    */ }


/* Location:              C:\Users\Shweyin\Desktop\Github\Seneca-work\JAC444\JAC444_w2_Shweyin.jar!\jac444\wk2\Circle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */